import xbmcgui
import xbmcplugin
import json
import urllib.parse
import sys
import xbmcaddon
import xbmc
import resolveurl
import random
import os

addon = xbmcaddon.Addon()

JSON_URL = 'https://raw.githubusercontent.com/Hanzaplast/petarcoinkodi/main/fm/strfilm'

COUNTRIES_PER_PAGE = 15

LOCAL_JSON_PATH = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'strfilm.json')

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def load_local_json():
    if not os.path.exists(LOCAL_JSON_PATH):
        return None
    try:
        with open(LOCAL_JSON_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f'Greška pri učitavanju lokalnog JSON-a: {e}')
        return None

def load_data_from_json():
    data = load_local_json()
    if data is not None:
        return data
    xbmcgui.Dialog().ok('Greška', 'Lokalni strfilm.json nije pronađen. Izaberite "Ažuriraj filmove" da preuzmete podatke.')
    return None

def get_all_genres_from_json(data):
    genres = set()
    for channel in data.get('channels', []):
        genre_text = channel.get('genre', '')
        if genre_text:
            for genre in genre_text.split(','):
                genres.add(genre.strip())
    return sorted(list(genres))

def get_movies_by_genre_from_json(data, genre):
    movies = []
    for channel in data.get('channels', []):
        genre_text = channel.get('genre', '')
        if genre_text:
            genres = [g.strip() for g in genre_text.split(',')]
            if genre in genres:
                movies.append(channel)
    return movies

def show_countries_list(page):
    data = load_data_from_json()
    if not data:
        return
    base_icon_url = 'http://balkandzo.byethost13.com/fomoti/'
    countries = data['countries']
    start_index = (page - 1) * COUNTRIES_PER_PAGE
    end_index = page * COUNTRIES_PER_PAGE

    # Dodaj opciju za ručni update json fajla na vrh
    list_item = xbmcgui.ListItem(label="[B]Ažuriraj filmove[/B]")
    url = "{0}?action=update_json".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

    # Prvo dodaj Pretraga i Svi filmovi na vrh
    list_item = xbmcgui.ListItem(label="[B]Pretraga[/B]")
    url = "{0}?action=search".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label="[B]Svi filmovi[/B]")
    url = "{0}?action=all_movies".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    # Dodaj "Novi Aktuelni Filmovi" kao folder, ali samo ako postoji u JSON-u
    for country in countries:
        if country['country'] == "Novi Aktuelni Filmovi":
            list_item = xbmcgui.ListItem(label="Novi Aktuelni Filmovi")
            url = "{0}?action=channels&country={1}".format(sys.argv[0], urllib.parse.quote("Novi Aktuelni Filmovi"))
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
            break

    # Dodaj "Najbolje ocenjeni" kao folder iznad žanrova
    list_item = xbmcgui.ListItem(label="[B]Najbolje ocenjeni[/B]")
    url = "{0}?action=top_rated".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    # Dodaj "Sortirano po žanru" kao folder
    list_item = xbmcgui.ListItem(label="[B]Sortirano po žanru[/B]")
    url = "{0}?action=genres".format(sys.argv[0])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_channels_list(country):
    data = load_data_from_json()
    if not data:
        return
    
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    
    for channel in data['channels']:
        if country.lower() in channel['country'].lower():
            runtime = channel.get('runtime', '')
            duration = int(runtime) * 60 if runtime.isdigit() else 0
            year = int(channel.get('year', 0)) if channel.get('year', '').isdigit() else 0
            rating = float(channel.get('rating', 0)) if channel.get('rating', '') else 0.0
            try:
                votes = int(float(channel.get('votes', 0))) if channel.get('votes', '') else 0
            except ValueError:
                votes = 0
            list_item = xbmcgui.ListItem(label=channel['channel'])
            list_item.setInfo('video', {
                'title': channel.get('channel', ''),
                'originaltitle': channel.get('originaltitle', ''),
                'year': year,
                'plot': channel.get('plot', ''),
                'genre': channel.get('genre', ''),
                'rating': rating,
                'votes': votes,
                'duration': duration,
            })
            thumb = channel.get('logo', '')
            fanart = ''
            if channel.get('fanart'):
                fanart = channel['fanart']
            art_dict = {'thumb': thumb}
            if fanart:
                art_dict['fanart'] = fanart
            list_item.setArt(art_dict)
            id1 = channel.get('id1')
            id2 = channel.get('id2')
            id3 = channel.get('id3')
            id4 = channel.get('id4')
            url = '{0}?action=play&id1={1}&id2={2}&id3={3}&id4={4}'.format(sys.argv[0], id1, id2, id3, id4)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def search(query):
    data = load_data_from_json()
    if not data:
        return

    base_icon_url = 'https://kodibalkan.com/fomoti/'

    results = []
    # Prvo pretrazi zemlje
    for country in data['countries']:
        country_name = country['country'].lower()
        if query.lower() in country_name:
            results.append({'type': 'country', 'data': country})

    # Zatim pretrazi filmove (kanale), ali van petlje za zemlje!
    for channel in data['channels']:
        channel_name = channel['channel'].lower()
        if query.lower() in channel_name:
            results.append({'type': 'channel', 'data': channel})

    for result in results:
        if result['type'] == 'country':
            list_item = xbmcgui.ListItem(label=result['data']['country'])
            encoded_country_name = urllib.parse.quote(result['data']['country'])
            icon_path = base_icon_url + encoded_country_name + '.jpg'  
            list_item.setArt({'icon': icon_path})
            url = '{0}?action=channels&country={1}'.format(sys.argv[0], encoded_country_name)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
        elif result['type'] == 'channel':
            list_item = xbmcgui.ListItem(label=result['data']['channel'])
            list_item.setArt({'thumb': result['data'].get('logo', '')})

            # Dodaj sve dostupne informacije iz JSON-a
            runtime = result['data'].get('runtime', '')
            duration = int(runtime) * 60 if runtime.isdigit() else 0
            year = int(result['data'].get('year', 0)) if result['data'].get('year', '').isdigit() else 0
            rating = float(result['data'].get('rating', 0)) if result['data'].get('rating', '') else 0.0
            try:
                votes = int(float(result['data'].get('votes', 0))) if result['data'].get('votes', '') else 0
            except ValueError:
                votes = 0

            list_item.setInfo('video', {
                'title': result['data'].get('channel', ''),
                'originaltitle': result['data'].get('originaltitle', ''),
                'year': year,
                'plot': result['data'].get('plot', ''),
                'genre': result['data'].get('genre', ''),
                'rating': rating,
                'votes': votes,
                'duration': duration,

            })
            
            id1 = result['data'].get('id1')
            id2 = result['data'].get('id2')
            id3 = result['data'].get('id3')
            id4 = result['data'].get('id4')

            url = '{0}?action=play&id1={1}&id2={2}&id3={3}&id4={4}'.format(sys.argv[0], id1, id2, id3, id4)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_all_movies():
    data = load_data_from_json()
    if not data:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    shown_titles = set()
    for channel in data['channels']:
        title = channel['channel']
        if title in shown_titles:
            continue
        shown_titles.add(title)
        runtime = channel.get('runtime', '')
        duration = int(runtime) * 60 if runtime.isdigit() else 0
        year = int(channel.get('year', 0)) if channel.get('year', '').isdigit() else 0
        rating = float(channel.get('rating', 0)) if channel.get('rating', '') else 0.0
        try:
            votes = int(float(channel.get('votes', 0))) if channel.get('votes', '') else 0
        except ValueError:
            votes = 0
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {
            'title': channel.get('channel', ''),
            'originaltitle': channel.get('originaltitle', ''),
            'year': year,
            'plot': channel.get('plot', ''),
            'genre': channel.get('genre', ''),
            'rating': rating,
            'votes': votes,
            'duration': duration,
        })
        thumb = channel.get('logo', '')
        fanart = ''
        if channel.get('fanart'):
            fanart = channel['fanart']
        art_dict = {'thumb': thumb}
        if fanart:
            art_dict['fanart'] = fanart
        list_item.setArt(art_dict)
        id1 = channel.get('id1')
        id2 = channel.get('id2')
        id3 = channel.get('id3')
        id4 = channel.get('id4')
        url = '{0}?action=play&id1={1}&id2={2}&id3={3}&id4={4}'.format(sys.argv[0], id1, id2, id3, id4)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_genres_list():
    data = load_data_from_json()
    if not data:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    genres = get_all_genres_from_json(data)
    for genre in genres:
        url = build_url({'action': 'genre', 'genre': genre})
        li = xbmcgui.ListItem(label=genre)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_channel(id1, id2, id3, id4):
    data = load_data_from_json()
    if not data:
        return

    urls = data['urls']

    # Automatski odaberi prvi dostupni stream
    if id1:
        url_group = 'urls1'
        chosen_id = id1
    elif id2:
        url_group = 'urls2'
        chosen_id = id2
    elif id3:
        url_group = 'urls3'
        chosen_id = id3
    elif id4:
        url_group = 'urls4'
        chosen_id = id4
    else:
        xbmcgui.Dialog().ok('Greška', 'Nijedan stream link nije pronađen.')
        return

    url = random.choice(urls[url_group])
    channel_url = url + chosen_id

    logo = ''
    channel_name = ''

    for channel in data['channels']:
        if (url_group == 'urls1' and channel.get('id1') == chosen_id) or \
           (url_group == 'urls2' and channel.get('id2') == chosen_id) or \
           (url_group == 'urls3' and channel.get('id3') == chosen_id) or \
           (url_group == 'urls4' and channel.get('id4') == chosen_id):
            channel_name = channel['channel']
            logo = channel['logo']
            break

    if not channel_name:
        xbmcgui.Dialog().ok('Greška', 'Izabrani film nije pronađen.')
        return

    list_item = xbmcgui.ListItem(label=channel_name)
    list_item.setArt({'thumb': logo})
    list_item.setInfo('video', {
        'title': channel_name,
        'genre': '',
        'year': '',
        'plot': '',
        'rating': '',
        'director': '',
        'cast': [],
        'duration': '',
    })

    playable_url = resolveurl.resolve(channel_url)
    if playable_url:
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
        xbmc.Player().play(playable_url, listitem=list_item)
    else:
        xbmcgui.Dialog().ok('Greška', 'Izabrani stream link ne radi. Pokrenite ponovo sadržaj da se izabere novi stream link.')

def show_top_rated_movies():
    data = load_data_from_json()
    if not data:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    # Sortiraj po oceni (rating), uzmi npr. top 30
    top_movies = sorted(data['channels'], key=lambda x: float(x.get('rating', 0)), reverse=True)[:30]
    shown_titles = set()
    for channel in top_movies:
        title = channel['channel']
        if title in shown_titles:
            continue
        shown_titles.add(title)
        runtime = channel.get('runtime', '')
        duration = int(runtime) * 60 if runtime.isdigit() else 0
        year = int(channel.get('year', 0)) if channel.get('year', '').isdigit() else 0
        rating = float(channel.get('rating', 0)) if channel.get('rating', '') else 0.0
        try:
            votes = int(float(channel.get('votes', 0))) if channel.get('votes', '') else 0
        except ValueError:
            votes = 0
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {
            'title': channel.get('channel', ''),
            'originaltitle': channel.get('originaltitle', ''),
            'year': year,
            'plot': channel.get('plot', ''),
            'genre': channel.get('genre', ''),
            'rating': rating,
            'votes': votes,
            'duration': duration,
        })
        thumb = channel.get('logo', '')
        fanart = channel.get('fanart', '')
        poster = channel.get('poster', '')
        art_dict = {'thumb': thumb}
        if fanart:
            art_dict['fanart'] = fanart
        if poster:
            art_dict['poster'] = poster
        list_item.setArt(art_dict)
        id1 = channel.get('id1')
        id2 = channel.get('id2')
        id3 = channel.get('id3')
        id4 = channel.get('id4')
        url = '{0}?action=play&id1={1}&id2={2}&id3={3}&id4={4}'.format(sys.argv[0], id1, id2, id3, id4)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def run_addon():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?', '')))
    action = params.get('action', None)
    
    if action is None:
        show_countries_list(page=1)
    elif action == 'country':
        page = int(params.get('page', 1))
        show_countries_list(page)
    elif action == 'channels':
        country = params['country']
        show_channels_list(country)
    elif action == 'play':
        id1 = params.get('id1')
        id2 = params.get('id2')
        id3 = params.get('id3')
        id4 = params.get('id4')
        play_channel(id1, id2, id3, id4)
    elif action == 'search':
        query = xbmcgui.Dialog().input('Unesite ključnu reč za pretragu zemlje')
        if query:
            search(query)
    elif action == 'genres':
        show_genres_list()
    elif action == 'genre':
        genre = params.get('genre')
        data = load_data_from_json()
        if not data:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            return
        movies = get_movies_by_genre_from_json(data, genre)
        for channel in movies:
            runtime = channel.get('runtime', '')
            duration = int(runtime) * 60 if runtime.isdigit() else 0
            year = int(channel.get('year', 0)) if channel.get('year', '').isdigit() else 0
            rating = float(channel.get('rating', 0)) if channel.get('rating', '') else 0.0
            try:
                votes = int(float(channel.get('votes', 0))) if channel.get('votes', '') else 0
            except ValueError:
                votes = 0
            list_item = xbmcgui.ListItem(label=channel['channel'])
            list_item.setInfo('video', {
                'title': channel.get('channel', ''),
                'originaltitle': channel.get('originaltitle', ''),
                'year': year,
                'plot': channel.get('plot', ''),
                'genre': channel.get('genre', ''),
                'rating': rating,
                'votes': votes,
                'duration': duration,
            })
            thumb = channel.get('logo', '')
            fanart = channel.get('fanart', '')
            poster = channel.get('poster', '')
            art_dict = {'thumb': thumb}
            if fanart:
                art_dict['fanart'] = fanart
            if poster:
                art_dict['poster'] = poster
            list_item.setArt(art_dict)
            id1 = channel.get('id1')
            id2 = channel.get('id2')
            id3 = channel.get('id3')
            id4 = channel.get('id4')
            url = '{0}?action=play&id1={1}&id2={2}&id3={3}&id4={4}'.format(sys.argv[0], id1, id2, id3, id4)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif action == 'all_movies':
        show_all_movies()
    elif action == 'update_json':
        try:
            with urllib.request.urlopen(JSON_URL) as response:
                data = json.load(response)
            # Upisi u lokalni fajl!
            with open(LOCAL_JSON_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            xbmcgui.Dialog().ok('Ažuriranje završeno', 'JSON podaci su ažurirani sa GitHub-a.')
        except Exception as e:
            xbmcgui.Dialog().ok('Greška', f'Neuspešno ažuriranje JSON-a: {e}')
        show_countries_list(page=1)
    elif action == 'top_rated':
        show_top_rated_movies()

if __name__ == '__main__':
    run_addon()
