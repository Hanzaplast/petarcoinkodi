import urllib.request
import xbmcgui
import xbmcaddon
import random
import re
import os
import sys
import xbmcvfs

# Balkan Dzo Addon by Dzon Dzoe


addon_id = 'plugin.video.worldclient'


if os.name == 'nt':  
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:  
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')


url = 'https://kodibalkan.com/KodiListe/testne.txt'


dialog = xbmcgui.DialogProgressBG()
dialog.create('Generisanje nove liste', 'Generise se nova lista. Molimo sacekajte...')


response = urllib.request.urlopen(url)
playlist_data = response.read().decode('utf-8')
playlist_urls = re.findall(r'http\S+', playlist_data)


with open(settings_path, 'r') as f:
    settings_xml = f.read()

current_url = re.findall('<setting id="m3u_url">(.*?)</setting>', settings_xml)[0]


new_url = current_url
while new_url == current_url:
    new_url = random.choice(playlist_urls)


def check_playlist(url):
    try:
        response = urllib.request.urlopen(url)
        return True
    except urllib.error.URLError:
        return False

if check_playlist(new_url):

    settings_xml = re.sub('<setting id="m3u_url">.*?</setting>', '<setting id="m3u_url">{}</setting>'.format(new_url), settings_xml)

    with open(settings_path, 'w') as f:
        f.write(settings_xml)


    xbmc.sleep(1000)


    dialog.close()


    xbmcgui.Dialog().ok('Uspesno generisana nova lista', 'Uspesno ste generisali novu listu. Kliknite U redu da biste zatvorili ovaj prozor.')


    sys.exit()
else:

    dialog.close()


    xbmcgui.Dialog().ok('Neuspesno generisana nova lista', 'Lista koju ste generisali ne radi . Molimo pokusajte ponovo.')


    sys.exit()
