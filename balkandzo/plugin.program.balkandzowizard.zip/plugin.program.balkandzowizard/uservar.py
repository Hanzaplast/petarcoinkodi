import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/BalkanDzo/balkandzo.github.io/raw/refs/heads/main/zips/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/BalkanDzo/balkandzo.github.io/raw/refs/heads/main/zips/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
